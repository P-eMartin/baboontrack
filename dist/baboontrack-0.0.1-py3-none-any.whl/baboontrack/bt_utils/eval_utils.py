import pdb

from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from pycocotools import mask as maskUtils
import json
import time
import sys
PYTHON_VERSION = sys.version_info[0]
import numpy as np
import pandas as pd
# To avoid the error "AttributeError: module 'numpy' has no attribute 'asfarray'" when using motmetrics
if not hasattr(np, "asfarray"):
    np.asfarray = lambda a, **kwargs: np.asarray(a, dtype=float)
import csv
import os
import copy
import re
from .io_utils import print_and_log, save_json_file, get_value_with_precision, save_dict_as_csv, zip_folder
from .json_utils import load_json_file
from collections import defaultdict
import zipfile
from .bot_sort.tracking_utils.evaluation import Evaluator

class myCOCO(COCO):
    '''
    Modified version of Coco where enmpty detections are handled gracefully instead of raising an error.
    '''
    def loadRes(self, resFile):
        """
        Load result file and return a result api object.

        Args:
            resFile (str or list): filename of result file or the results as a list of dicts.

        Returns:
            myCOCO: result api object
        """
        res = COCO()
        res.dataset['info'] = copy.deepcopy(self.dataset.get('info', {}))
        res.dataset['images'] = [img for img in self.dataset['images']]

        print('Loading and preparing results...')
        tic = time.time()
        if type(resFile) == str or (PYTHON_VERSION == 2 and type(resFile) == unicode): # type: ignore
            with open(resFile) as f:
                anns = json.load(f)
        elif type(resFile) == np.ndarray:
            anns = self.loadNumpyAnnotations(resFile)
        else:
            anns = resFile
        assert type(anns) == list, 'results in not an array of objects'
        annsImgIds = [ann['image_id'] for ann in anns]
        assert set(annsImgIds) == (set(annsImgIds) & set(self.getImgIds())), \
               'Results do not correspond to current coco set'
        # Case when the results are empty
        if len(anns) == 0:
            print('Results is empty.')
            res.dataset['annotations'] = []
            res.createIndex()
            return res
        if 'caption' in anns[0]:
            imgIds = set([img['id'] for img in res.dataset['images']]) & set([ann['image_id'] for ann in anns])
            res.dataset['images'] = [img for img in res.dataset['images'] if img['id'] in imgIds]
            for id, ann in enumerate(anns):
                ann['id'] = id+1
        elif 'bbox' in anns[0] and not anns[0]['bbox'] == []:
            res.dataset['categories'] = copy.deepcopy(self.dataset['categories'])
            for id, ann in enumerate(anns):
                bb = ann['bbox']
                x1, x2, y1, y2 = [bb[0], bb[0]+bb[2], bb[1], bb[1]+bb[3]]
                if not 'segmentation' in ann:
                    ann['segmentation'] = [[x1, y1, x1, y2, x2, y2, x2, y1]]
                ann['area'] = bb[2]*bb[3]
                ann['id'] = id+1
                ann['iscrowd'] = 0
        elif 'segmentation' in anns[0]:
            res.dataset['categories'] = copy.deepcopy(self.dataset['categories'])
            for id, ann in enumerate(anns):
                # now only support compressed RLE format as segmentation results
                ann['area'] = maskUtils.area(ann['segmentation'])
                if not 'bbox' in ann:
                    ann['bbox'] = maskUtils.toBbox(ann['segmentation'])
                ann['id'] = id+1
                ann['iscrowd'] = 0
        elif 'keypoints' in anns[0]:
            res.dataset['categories'] = copy.deepcopy(self.dataset['categories'])
            for id, ann in enumerate(anns):
                s = ann['keypoints']
                x = s[0::3]
                y = s[1::3]
                x0,x1,y0,y1 = np.min(x), np.max(x), np.min(y), np.max(y)
                ann['area'] = (x1-x0)*(y1-y0)
                ann['id'] = id + 1
                ann['bbox'] = [x0,y0,x1-x0,y1-y0]
        print('DONE (t={:0.2f}s)'.format(time.time()- tic))

        res.dataset['annotations'] = anns
        res.createIndex()
        return res

class myCOCOeval(COCOeval):
    '''
    Modified version of Coco eval where classes can be ignored in the evaluation because the annotators are not certain of
    the category of the object. This is useful for example when the annotators are not sure of the identity of the baboon
    in the image and they want to ignore it in the evaluation of classification, but not in the evaluation of detection.
    '''
    def __init__(self, cocoGt=None, cocoDt=None, iouType='segm', ignore_classes=[]):
        super().__init__(cocoGt, cocoDt, iouType)
        self.ignore_classes = ignore_classes

    def _prepare(self):
        super()._prepare()
        if self.ignore_classes:
            for gt in self._gts:
                for g in self._gts[gt]:
                    if g['category_id'] in self.ignore_classes:
                        g['ignore'] = 1

'''
Helper
'''
def extract_boundaries(filename, log=None):
    """
    Extract frame boundaries from filenames like:
    - frame-1-546-1639-2000-mot
    - frame-1-546-mot.zip
    - frames.zip

    Returns:
        list of (start, end) tuples or None
    """

    base = os.path.basename(filename)
    base = base.replace(".zip", "")

    # Extract all integers in order
    nums = list(map(int, re.findall(r"\d+", base)))

    # If no numbers → no boundaries
    if not nums:
        return None

    # Must be even number of values to form pairs
    if len(nums) % 2 != 0:
        print_and_log(f"Odd number of boundary values found in: {filename}. Setting to None.", log=log)
        return None

    # Pair them
    boundaries = [(nums[i], nums[i + 1]) for i in range(0, len(nums), 2)]
    print_and_log(f"Extracted boundaries from {filename}: {boundaries}", log=log)

    return boundaries

'''
Saving formats
'''
def coco_to_perso_format(coco_list, image_size=None, frame_id_offset=0):
    '''
    Convert a COCO-format list of annotations to a custom format.

    Args:
        coco_list: list of dict, the COCO-format list of annotations
        image_size: list of int, the size of the image in the format [width, height] (default None, if None, the bbox coordinates are not normalized)
        frame_id_offset: int, the offset to add to the frame IDs (default 0, to keep the same frame IDs)

    Returns:
        list of dict, the custom-format list of annotations
    '''
    perso_list = [[] for i in range(frame_id_offset)] # Initialize the perso_list with empty lists for the frame ID offset
    det_list = []
    prev_img_id = 1
    for det in coco_list:
        img_id = det['image_id']
        if prev_img_id != img_id:
            perso_list.append(det_list)
            det_list = []
            # Add empty lists for the frames between the previous image ID and the current image ID
            for _ in range(img_id - prev_img_id - 1):
                perso_list.append([])
            prev_img_id = img_id
        det_list.append({
            'image_id': det['image_id'] + frame_id_offset,
            'category_id': det['category_id'],
            'bbox': det['bbox'] if image_size is None else [
                det['bbox'][0] / image_size[0],
                det['bbox'][1] / image_size[1],
                det['bbox'][2] / image_size[0],
                det['bbox'][3] / image_size[1]
            ],
            'score': det.get('score'),
            'track_id': det.get('track_id', det.get('attributes', {}).get('track_id')),
            # Add segmentation if available
            'segmentation': det.get('segmentation'),
        })
    perso_list.append(det_list)
    return perso_list

def perso_format_to_trackid_format(perso_list):
    '''
    Convert a custom-format list of annotations to a track ID format.

    Args:
        perso_list: list of list of dict, the custom-format list of annotations

    Returns:
        dict, key: track ID, value: list of annotations
    '''
    trackid_dict = defaultdict(list)
    for idx, frame_dets in enumerate(perso_list):
        for det in frame_dets:
            det['image_id'] = idx + 1
            trackid_dict[det['track_id']].append(det)
    return dict(trackid_dict)

def save_coco_format(detection_dict, output_path, image_size=None, labels=None, boundaries=None, frame_id_offset=0):
    '''
    Save the detection and tracking results in COCO format.

    Args:
        detection_dict: dict, the detection and tracking results
        output_path: str, the path to save the output file
        image_size: list of int, the size of the image in the format [width, height] (default None, if None, the bbox coordinates are not normalized)
        labels: list of str, the list of labels to save in a separate file (default None)
        boundaries: list of tuple of int, the boundaries of the frames to save (default None)
        frame_id_offset: int, the offset to add to the frame IDs (default 0, no offset)

    Returns:
        int, 1 if the file was properly saved
    '''
    # Create the COCO format dictionary
    coco_list = []
    # Loop over the detection_dict and fill the COCO format dictionary
    for idx, dets_or_key in enumerate(detection_dict):
        if isinstance(dets_or_key, list): # Case when dets_or_key is a list of detections
            if boundaries and not (any(start <= idx <= end for start, end in boundaries)):
                continue
            for det in dets_or_key:
                coco_list.append({
                    'image_id': idx + 1 + frame_id_offset,
                    'category_id': det['category_id'],
                    'bbox': [
                        get_value_with_precision(det['bbox'][0] * image_size[0] if image_size is not None else det['bbox'][0], 10),
                        get_value_with_precision(det['bbox'][1] * image_size[1] if image_size is not None else det['bbox'][1], 10),
                        get_value_with_precision(det['bbox'][2] * image_size[0] if image_size is not None else det['bbox'][2], 10),
                        get_value_with_precision(det['bbox'][3] * image_size[1] if image_size is not None else det['bbox'][3], 10)
                    ],
                    'score': get_value_with_precision(det.get('score')),
                    'attributes': {
                        'name': 'NoID',
                        'track_id': int(det['track_id'] + 1),
                        'visibility': det.get('visibility', 1),
                    }
                })
        else: # Case when detection_dict is a list of dictionaries (already in COCO format)
            det = dets_or_key
            if boundaries and not (any(start <= det['image_id']-1 <= end for start, end in boundaries)):
                continue
            coco_list.append({
                'image_id': det['image_id'] + frame_id_offset,
                'category_id': det['category_id'],
                'bbox': [
                    get_value_with_precision(det['bbox'][0] * image_size[0], 10) if image_size is not None else det['bbox'][0],
                    get_value_with_precision(det['bbox'][1] * image_size[1], 10) if image_size is not None else det['bbox'][1],
                    get_value_with_precision(det['bbox'][2] * image_size[0], 10) if image_size is not None else det['bbox'][2],
                    get_value_with_precision(det['bbox'][3] * image_size[1], 10) if image_size is not None else det['bbox'][3]
                ],
                'score': get_value_with_precision(det.get('score')),
                'area': det['area'] if 'area' in det else get_value_with_precision(det['bbox'][2] * det['bbox'][3] if image_size is None else det['bbox'][2] * image_size[0] * det['bbox'][3] * image_size[1], 10),
                'iscrowd': det['iscrowd'] if 'iscrowd' in det else 0,
                'attributes': {
                    'name': 'NoID',
                    'track_id': det.get('track_id', det.get('attributes', {}).get('track_id')),
                    'visibility': det['visibility'] if 'visibility' in det else 1,
                }
            })
    os.makedirs(output_path, exist_ok=True)
    output_file = os.path.join(output_path, 'detections.json')
    save_json_file(coco_list, output_file)
    save_json_file(coco_list, output_file.replace('.json', '.pretty.json'), pretty=True)
    # Save labels if provided
    if labels is not None:
        save_json_file(labels, os.path.join(output_path, 'labels.json'))
    return output_file

def save_mot_format(detection_dict, output_path, image_size=None, labels=None, boundaries=None, cat_id_override=None, frame_id_offset=1):
    '''
    Save the detection and tracking results in MOT format.

    Args:
        detection_dict: dict, the detection and tracking results
        output_path: str, the path to save the output files
        image_size: list of int, the size of the image in the format [width, height] (default None, if None, the bbox coordinates are not normalized)
        labels: list of str, the list of labels to save in a separate file (default None)
        boundaries: list of tuple of int, the boundaries of the frames to save (default None)
        cat_id_override: int, the category ID to use as override for all annotations (default None, if None, the provided category ID is used)
        frame_id_offset: int, the offset to add to the frame IDs (default 1, to start from 1 instead of 0)

    Returns:
        int, 1 if the file was properly saved
    '''
    # Create the MOT format dictionary - leading # in the first key so it is considered as comment in the MOT format
    folder_to_zip = os.path.join(output_path, 'gt')
    os.makedirs(folder_to_zip, exist_ok=True)
    mot_dict = {
        'frame_id': [],
        'track_id': [],
        'x': [],
        'y': [],
        'w': [],
        'h': [],
        'not ignored': [],
        'class_id': [],
        'visibility': [],
        'skipped': []
    }
    # Loop over the detection_dict and fill the MOT format dictionary
    for idx, dets_or_key in enumerate(detection_dict):
        if isinstance(dets_or_key, list): # Case when dets_or_key is a list of detections
            if boundaries and not (any(start <= idx <= end for start, end in boundaries)):
                continue
            for det in dets_or_key:
                mot_dict['frame_id'].append(idx+frame_id_offset)
                mot_dict['track_id'].append(det['track_id']+1)
                mot_dict['x'].append(int(det['bbox'][0] * image_size[0]) if image_size is not None else det['bbox'][0])
                mot_dict['y'].append(int(det['bbox'][1] * image_size[1]) if image_size is not None else det['bbox'][1])
                mot_dict['w'].append(int(det['bbox'][2] * image_size[0]) if image_size is not None else det['bbox'][2])
                mot_dict['h'].append(int(det['bbox'][3] * image_size[1]) if image_size is not None else det['bbox'][3])
                mot_dict['not ignored'].append(1)
                mot_dict['class_id'].append(cat_id_override if cat_id_override is not None else det['category_id'])
                mot_dict['visibility'].append(det.get('visibility', 1))
                mot_dict['skipped'].append(0)
        elif isinstance(detection_dict, dict): # Case when detection_dict is a dictionary with dets_or_key being the key.
            if boundaries and not (any(start <= int(dets_or_key)-1 <= end for start, end in boundaries)):
                continue
            dets = detection_dict[dets_or_key]
            for det in dets:
                if isinstance(det, dict):
                    mot_dict['frame_id'].append(dets_or_key + frame_id_offset -1)
                    mot_dict['track_id'].append(det['track_id'])
                    mot_dict['x'].append(int(det['bbox'][0] * image_size[0]) if image_size is not None else det['bbox'][0])
                    mot_dict['y'].append(int(det['bbox'][1] * image_size[1]) if image_size is not None else det['bbox'][1])
                    mot_dict['w'].append(int(det['bbox'][2] * image_size[0]) if image_size is not None else det['bbox'][2])
                    mot_dict['h'].append(int(det['bbox'][3] * image_size[1]) if image_size is not None else det['bbox'][3])
                    mot_dict['not ignored'].append(det.get('not_ignored', 1))
                    mot_dict['class_id'].append(cat_id_override if cat_id_override is not None else det['category_id'])
                    mot_dict['visibility'].append(det.get('visibility', 1))
                    mot_dict['skipped'].append(det.get('skipped', 0))
                elif isinstance(det, list):
                    for _det in det:
                        mot_dict['frame_id'].append(dets_or_key + frame_id_offset -1)
                        mot_dict['track_id'].append(_det['track_id'])
                        mot_dict['x'].append(int(_det['bbox'][0] * image_size[0]) if image_size is not None else _det['bbox'][0])
                        mot_dict['y'].append(int(_det['bbox'][1] * image_size[1]) if image_size is not None else _det['bbox'][1])
                        mot_dict['w'].append(int(_det['bbox'][2] * image_size[0]) if image_size is not None else _det['bbox'][2])
                        mot_dict['h'].append(int(_det['bbox'][3] * image_size[1]) if image_size is not None else _det['bbox'][3])
                        mot_dict['not ignored'].append(_det.get('not_ignored', 1))
                        mot_dict['class_id'].append(cat_id_override if cat_id_override is not None else _det['category_id'])
                        mot_dict['visibility'].append(_det.get('visibility', 1))
                        mot_dict['skipped'].append(_det.get('skipped', 0))
        else: # Case when detection_dict is a list of dictionaries (in COCO format)
            det = dets_or_key
            if boundaries and not (any(start <= det['image_id']-1 <= end for start, end in boundaries)):
                continue
            mot_dict['frame_id'].append(det['image_id'] + frame_id_offset -1)
            mot_dict['track_id'].append(det['track_id'])
            mot_dict['x'].append(int(det['bbox'][0] * image_size[0]) if image_size is not None else det['bbox'][0])
            mot_dict['y'].append(int(det['bbox'][1] * image_size[1]) if image_size is not None else det['bbox'][1])
            mot_dict['w'].append(int(det['bbox'][2] * image_size[0]) if image_size is not None else det['bbox'][2])
            mot_dict['h'].append(int(det['bbox'][3] * image_size[1]) if image_size is not None else det['bbox'][3])
            mot_dict['not ignored'].append(det.get('not_ignored', 1))
            mot_dict['class_id'].append(cat_id_override if cat_id_override is not None else det['category_id'])
            mot_dict['visibility'].append(det.get('visibility', 1))
            mot_dict['skipped'].append(det.get('skipped', 0))
    output_file = os.path.join(folder_to_zip, 'gt.txt')
    save_dict_as_csv(mot_dict, output_file, without_headers=True)
    # Save labels if provided
    if labels is not None:
        with open(os.path.join(folder_to_zip, 'labels.txt'), 'w') as f:
            for label in labels:
                f.write('%s\n' % (label))
    zip_folder(folder_to_zip, os.path.join(output_path, 'mot.zip'))
    return output_file

def load_mot_format(input_file, boundaries=None, log=None):
    '''
    Load detection/tracking results from a MOT-format file.

    Args:
        input_file: str, the path to the input file (can be a zip file, a folder containing gt/gt.txt, or a gt.txt file)
        boundaries: list of tuple of int, the start and end frame IDs to load (default None, if None, all frames are loaded)
        log: logging.Logger, the logger to log the information (default None)

    Returns:
        dict: a dictionary containing the loaded detection/tracking results, with frame IDs as keys and
            lists of detections as values. Each detection is a dictionary with keys 'id','track_id', 'bbox', 'category_id', 'visibility', 'not_ignored', and 'skipped'.
    '''
    labels = None
    def parse_rows(reader):
        detection_dict = defaultdict(list)

        for idx, row in enumerate(reader):
            frame_id = int(row[0])

            detection_dict[frame_id].append({
                "id": idx+1,
                "track_id": int(row[1]),
                "bbox": [
                    max(int(float(row[2])), 0),
                    max(int(float(row[3])), 0),
                    max(int(float(row[4])), 0),
                    max(int(float(row[5])), 0)
                ],
                "category_id": int(float(row[7])),
                "visibility": float(row[8]),
                "not_ignored": int(row[6]),
                "skipped": int(row[9]) if len(row) > 9 else 0
            })

        return dict(detection_dict)

    if zipfile.is_zipfile(input_file):
        with zipfile.ZipFile(input_file) as zf:
            with zf.open("gt/gt.txt") as f:
                reader = csv.reader(line.decode() for line in f)
                detection_dict = parse_rows(reader)
            with zf.open("gt/labels.txt") as f:
                labels = [line.decode().strip() for line in f]

    elif os.path.isdir(input_file):
        with open(os.path.join(input_file, "gt", "gt.txt"), newline="") as f:
            detection_dict = parse_rows(csv.reader(f))
        with open(os.path.join(input_file, "gt", "labels.txt"), "r") as f:
            labels = [line.strip() for line in f]

    elif os.path.isfile(input_file):
        with open(input_file, newline="") as f:
            detection_dict = parse_rows(csv.reader(f))

    else:
        raise ValueError(
            f"Input '{input_file}' is not a valid zip file, folder, or file."
        )

    if boundaries is not None:
        detection_dict = {
            frame_id: dets
            for frame_id, dets in detection_dict.items()
            if any(start <= frame_id-1 <= end for start, end in boundaries)
        }

    return detection_dict, labels

def mot_to_coco_format(mot_dict, image_size=None, cat_id_override=None):
    '''
    Convert a MOT-format dictionary to COCO format.

    Args:
        mot_dict: dict, the MOT-format dictionary to convert
        image_size: list of int, the size of the image in the format [width, height] (default None, if None, the bbox coordinates are not normalized)
        cat_id_override: int, the category ID to use as override for all annotations (default None, if None, the provided category ID is used)

    Returns:
        list of dict, the converted COCO-format list of annotations
    '''
    coco_list = []
    idx = -1
    for frame_id, dets in mot_dict.items():
        for det in dets:
            idx += 1
            coco_list.append({
                'id': idx,
                'image_id': frame_id,
                'category_id': cat_id_override if cat_id_override is not None else det['category_id'],
                'bbox': [
                    get_value_with_precision(det['bbox'][0] * image_size[0] if image_size is not None else det['bbox'][0], 10),
                    get_value_with_precision(det['bbox'][1] * image_size[1] if image_size is not None else det['bbox'][1], 10),
                    get_value_with_precision(det['bbox'][2] * image_size[0] if image_size is not None else det['bbox'][2], 10),
                    get_value_with_precision(det['bbox'][3] * image_size[1] if image_size is not None else det['bbox'][3], 10)
                ],
                'score': get_value_with_precision(det.get('score')),
                'iscrowd': 0,
                'area': get_value_with_precision(det['bbox'][2] * det['bbox'][3] if image_size is None else det['bbox'][2] * image_size[0] * det['bbox'][3] * image_size[1], 10),
                'attributes': {
                    'name': 'NoID',
                    'track_id': int(det['track_id'] + 1),
                    'visibility': det['visibility'] if 'visibility' in det else 1,
                }
            })
    return coco_list

def mot_gt_to_coco_gt(mot_gt_file, image_size=None, cat_id_override=None, categories=None):
    '''
    Convert a MOT-format ground truth file to COCO format.

    Args:
        mot_gt_file: str or dict, the path to the MOT-format ground truth file (can be a zip file, a folder containing gt/gt.txt, or a gt.txt file)
        image_size: list of int, the size of the image in the format [width, height] (default None, if None, the bbox coordinates are not normalized)
        cat_id_override: int, the category ID to use as override for all annotations (default None, if None, the provided category ID is used)
        categories: list, the list of category names to include in the COCO output (default None)

    Returns:
        dict, the converted COCO-format ground truth dictionary with 'annotations' and 'categories'
    '''
    if isinstance(mot_gt_file, str):
        mot_dict, mot_categories = load_mot_format(mot_gt_file)
        if categories is None:
            categories = mot_categories
    else:
        mot_dict = mot_gt_file
    coco_gt = {
        'images': [{'id': frame_id, 'width': image_size[0] if image_size is not None else 1920, 'height': image_size[1] if image_size is not None else 1080} for frame_id in mot_dict.keys()],
        'annotations': mot_to_coco_format(mot_dict, cat_id_override=cat_id_override),
        'categories': [{'id': idx+1, 'name': cat} for idx, cat in enumerate(categories)] if categories is not None else [{'id': 1, 'name': 'NoID'}]
    }
    return coco_gt

def update_eval_csv(
    csv_path,
    segment_name,
    metrics,
    extra_info=None,
):
    """
    Update or append evaluation results in a CSV file.

    Args:
        csv_path: str
            Path to CSV file storing all evaluations.

        segment_name: str
            Unique identifier for the evaluated video/segment.

        metrics: dict
            COCO evaluation metrics.

        extra_info: dict (optional)
            Additional metadata (e.g., video length, FPS, model name).
    """

    # ------------------------------------------------------------
    # 1. Build row dictionary
    # ------------------------------------------------------------
    row = {"segment_name": segment_name}

    # add metrics
    row.update(metrics)

    # add optional metadata
    if extra_info is not None:
        row.update(extra_info)

    # ------------------------------------------------------------
    # 2. Load existing CSV if it exists
    # ------------------------------------------------------------
    if os.path.exists(csv_path):
        df = pd.read_csv(csv_path)
    else:
        df = pd.DataFrame()

    # ------------------------------------------------------------
    # 3. Update or append row
    # ------------------------------------------------------------
    if "segment_name" in df.columns and segment_name in df["segment_name"].values:

        # overwrite existing row
        df.loc[df["segment_name"] == segment_name, row.keys()] = row.values()

    else:
        # append new row
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)

    # ------------------------------------------------------------
    # 4. Save back
    # ------------------------------------------------------------
    df.to_csv(csv_path, index=False)

def solve_id_conflicts(_detections, labels_input, labels_output, default_label="NoID", log=None):
    '''
    Solve ID conflicts between input labels (name) and expetected labels by matching labels from input
    to the expected labels. Check if name match (lower case) and modify id accordingly. If no match, assign default label and log the conflict.

    Args:
        detections: list of dict, the list of detections with 'category_id' key
        labels_input: list of str, the list of input labels (names)
        labels_output: list of str, the list of expected output labels (names)
        default_label: str, the default label to assign in case of conflict (default "NoID")
        log: logging.Logger, the logger to log the information (default None)
    
    Returns:
        list of dict, the list of detections with resolved ID conflicts
    '''
    detections = copy.deepcopy(_detections) # To avoid modifying the original detections
    name_to_id_output = {label.lower(): idx+1 for idx, label in enumerate(labels_output)}
    nb_id_conflict = 0
    total_detections = 0
    for det in detections:
        if isinstance(det, dict):
            total_detections += 1
            id_input = det['category_id']
            name = labels_input[id_input-1].lower()
            if name in name_to_id_output:
                det['category_id'] = name_to_id_output[name]
            else:
                nb_id_conflict += 1
                det['category_id'] = name_to_id_output.get(default_label.lower(), 0)
        elif isinstance(det, list):
            for _det in det:
                total_detections += 1
                id_input = _det['category_id']
                name = labels_input[id_input-1].lower()
                if name in name_to_id_output:
                    _det['category_id'] = name_to_id_output[name]
                else:
                    nb_id_conflict += 1
                    _det['category_id'] = name_to_id_output.get(default_label.lower(), 0)
    print_and_log(f"Total ID conflicts resolved: {nb_id_conflict} over {total_detections} detections.", log=log)
    return detections

#####
## Evaluation of the detection and tracking results
#####
def coco_eval(gt_file, detection_file, ignore_classes=[]):
    """
    Run COCO evaluation and return metrics as a flat dictionary.
    """

    coco_gt = myCOCO(gt_file)
    # Check quickly if there are any detections otherwise loading lead to error:
    # if len(load_json_file(detection_file)) == 0:
    #     coco_dt = coco_gt.loadRes([{'image_id':1,'id':0,'category_id':1,'bbox':[0,0,0,0],'score':0}])
    # else:
    coco_dt = coco_gt.loadRes(detection_file)
    
    coco_eval = myCOCOeval(coco_gt, coco_dt, iouType="bbox", ignore_classes=ignore_classes)
    coco_eval.evaluate()
    coco_eval.accumulate()
    coco_eval.summarize()

    return {
        "AP": coco_eval.stats[0],
        "AP50": coco_eval.stats[1],
        "AP75": coco_eval.stats[2],
        "AP_small": coco_eval.stats[3],
        "AP_medium": coco_eval.stats[4],
        "AP_large": coco_eval.stats[5],
        "AR": coco_eval.stats[6],
        "AR50": coco_eval.stats[7],
        "AR75": coco_eval.stats[8],
        "AR_small": coco_eval.stats[9],
        "AR_medium": coco_eval.stats[10],
        "AR_large": coco_eval.stats[11],
    }

def evaluate_detection(gt_file, detection_file, name=None, save_path=None, extra_info=None, ignore_classes=[]):
    '''
    Evaluate the detection performance using COCO metrics.

    Args:
        gt_file: str, path to the ground truth JSON file or zip file in COCO format
        detection_file: str, path to the detection JSON file or zip file in COCO format
        save_path: str, path to save the evaluation results (default None)
        extra_info: dict (optional), additional metadata to include in the evaluation results
        ignore_classes: list of int, list of category IDs to ignore in the evaluation (default empty list)

    Returns:
        dict, the evaluation results
    '''
    metrics = coco_eval(gt_file, detection_file, ignore_classes=ignore_classes)
    if save_path is not None:
        update_eval_csv(
            csv_path=save_path,
            segment_name=name if name is not None else os.path.basename(detection_file).split('.')[0],
            metrics=metrics,
            extra_info=extra_info
        )
    return metrics

def mot_eval(gt_file, tracking_file):
    """
    Evaluate MOT tracking performance and return a flat dictionary.
    Can process file/file or folder/folder (in which case it will return the average metrics across all files).

    Args:
        gt_file: str, path to the ground truth MOT file (can be a zip file, a folder containing gt/gt.txt, or a gt.txt file)
        tracking_file: str, path to the tracking results MOT file (can be a zip file, a folder containing gt/gt.txt, or a gt.txt file)

    Returns:
        dict, the evaluation results
    """
    if isinstance(gt_file, list) and isinstance(tracking_file, list):
        print("Warning: this works only if track_id are updated properly across sequences (not overlapping ids) unless the files are meant to be evaluated together. If not, the evaluation will be incorrect.")
        # If both are lists, evaluate each pair of files and average the results
        if len(gt_file) != len(tracking_file):
            print("Length of gt_file and tracking_file lists are not the same. Skipping evaluation.")
            return {}
        elif len(gt_file) == 0:
            print("gt_file and tracking_file lists are empty. Skipping evaluation.")
            return {}
        for idx, (gt_f, tr_f) in enumerate(zip(gt_file, tracking_file)):
            data_root = os.path.dirname(gt_f)
            seq_name = os.path.basename(gt_f).split('.')[0]
            if idx == 0:
                # Initialize the evaluator with the first sequence
                evaluator = Evaluator(data_root, seq_name, data_type="mot")
            else:
                # Update the evaluator with the next sequence
                evaluator.data_root = data_root
                evaluator.seq_name = seq_name
                evaluator.load_annotations()
            eval_results = evaluator.eval_file(os.path.join(tr_f, 'gt', 'gt.txt') if os.path.isdir(tr_f) else tr_f, reset_accumulator=False)
    else:
        data_root = os.path.dirname(gt_file)
        seq_name = os.path.basename(gt_file).split('.')[0]
        evaluator = Evaluator(data_root, seq_name, data_type="mot")
        eval_results = evaluator.eval_file(tracking_file)

    summary = evaluator.get_summary([eval_results], [seq_name])

    # ------------------------------------------------------------
    # Extract ONLY the OVERALL row (remove duplication noise)
    # ------------------------------------------------------------
    if "OVERALL" in summary.index:
        row = summary.loc["OVERALL"]
    else:
        row = summary.iloc[0]

    # convert to clean dict
    metrics = row.to_dict()

    # add identifier
    metrics["sequence"] = seq_name

    return metrics

def evaluate_tracking(gt_file, tracking_file, save_path=None, name=None, extra_info=None):
    '''
    Evaluate the tracking performance using MOT metrics.

    Args:
        gt_file: str, path to the ground txt file or zip file in MOT format
        tracking_file: str, path to the tracking results file in MOT format
        save_path: str, path to save the evaluation results (default None)
        name: str, name of the sequence (default None)
        extra_info: dict (optional), additional metadata to include in the evaluation results

    Returns:
        dict, the evaluation results
    '''
    metrics = mot_eval(gt_file, tracking_file)
    if save_path is not None:
        update_eval_csv(
            csv_path=save_path,
            segment_name=name if name is not None else os.path.basename(tracking_file).split('.')[0],
            metrics=metrics,
            extra_info=extra_info
        )
    return metrics

def merge_mot_formats(gt_files, pred_mot_files, output_folder):
    '''
    Merge multiple MOT-format files into a single MOT-format file to be able to evaluate
    a whole dataset at once. The merged file will be saved in the output_folder.
    The track_id and frame_id will be updated accordingly to avoid conflicts.
    We need both gt_files and pred_mot_files in order to be able to modify properly the track_id and frame_id in the merged file.

    Args:
        gt_files: list of str, paths to the ground truth MOT-format files (can be zip files, folders containing gt/gt.txt, or gt.txt files)
        pred_mot_files: list of str, paths to the prediction MOT-format files (can be zip files, folders containing pred/pred.txt, or pred.txt files)
        output_folder: str, path to the folder where the merged file will be saved

    Returns:
        list of str, paths to the merged MOT-format files
    '''
    if len(gt_files) != len(pred_mot_files):
        raise ValueError("The number of ground truth files and prediction files must be the same.")
    merged_gt = defaultdict(list)
    merged_pred = defaultdict(list)
    track_id_offset_gt = 0
    track_id_offset_pred = 0
    frame_id_offset = 0
    for gt_file, pred_file in zip(gt_files, pred_mot_files):
        gt_dict, _ = load_mot_format(gt_file)
        pred_dict, _ = load_mot_format(pred_file)
        # Update track_id and frame_id in gt_dict
        if frame_id_offset > 0 and track_id_offset_gt > 0:
            for frame_id, dets in gt_dict.items():
                for det in dets:
                    det['track_id'] += track_id_offset_gt
        # Update track_id and frame_id in pred_dict
        if frame_id_offset > 0 and track_id_offset_pred > 0:
            for frame_id, dets in pred_dict.items():
                for det in dets:
                    det['track_id'] += track_id_offset_pred
        for frame_id, dets in gt_dict.items():
            merged_gt[frame_id+frame_id_offset].append(dets)
        for frame_id, dets in pred_dict.items():
            merged_pred[frame_id+frame_id_offset].append(dets)
        # Update offsets for next iteration
        frame_id_offset = max(max(merged_gt.keys(), default=0), max(merged_pred.keys(), default=0)) + 1
        track_id_offset_gt += max([det['track_id'] for dets in gt_dict.values() for det in dets], default=0) + 1
        track_id_offset_pred += max([det['track_id'] for dets in pred_dict.values() for det in dets], default=0) + 1
    # Save merged files
    merged_gt_path = os.path.join(output_folder, 'merged_gt')
    merged_pred_path = os.path.join(output_folder, 'merged_pred')
    save_mot_format(merged_gt, merged_gt_path)
    merged_pred_file = save_mot_format(merged_pred, merged_pred_path)
    return merged_gt_path, merged_pred_file

def merge_coco_formats(gt_files, detection_files, output_folder):
    '''
    Merge multiple COCO-format ground truth and detection files into a single COCO-format files to be able to evaluate
    a whole dataset at once. The merged files will be saved in the output_folder.
    Both are needed in order to be able to modify properly the image_id and annotation_id in the merged files.

    Args:
        gt_files: list of str, paths to the ground truth JSON files in COCO format
        detection_files: list of str, paths to the detection JSON files in COCO format
        output_folder: str, path to the folder where the merged files will be saved

    Returns:
        tuple of str, paths to the merged ground truth and detection JSON files in COCO format
    '''
    if len(gt_files) != len(detection_files):
        raise ValueError("The number of ground truth files and detection files must be the same.")
    merged_gt = {
        'images': [],
        'annotations': [],
        'categories': []
    }
    merged_dt = []
    image_id_offset = 0
    annotation_id_offset = 0
    for gt_file, dt_file in zip(gt_files, detection_files):
        gt_data = load_json_file(gt_file)
        dt_data = load_json_file(dt_file)
        # Update image_id and annotation_id in gt_data
        for img in gt_data['images']:
            img['id'] += image_id_offset
            merged_gt['images'].append(img)
        for ann in gt_data['annotations']:
            ann['id'] += annotation_id_offset
            ann['image_id'] += image_id_offset
            merged_gt['annotations'].append(ann)
        # Update image_id in dt_data
        for det in dt_data:
            det['image_id'] += image_id_offset
            merged_dt.append(det)
        # Update offsets for next iteration
        image_id_offset += len(gt_data['images'])
        annotation_id_offset += len(gt_data['annotations'])
    # Merge categories (assuming they are the same across all files)
    merged_gt['categories'] = gt_data['categories']
    # Save merged files
    os.makedirs(output_folder, exist_ok=True)
    merged_gt_file = os.path.join(output_folder, 'merged_gt.json')
    merged_dt_file = os.path.join(output_folder, 'merged_dt.json')
    save_json_file(merged_gt, merged_gt_file)
    save_json_file(merged_dt, merged_dt_file)
    return merged_gt_file, merged_dt_file
